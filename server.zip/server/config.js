export const SMTP_HOST = 'smtp.gmail.com'
export const SMTP_PORT = '587'
export const SMTP_USER = 'vla3ik@gmail.com'
export const SMTP_PASS = 'znjusdnhtursfhjm'

export const API_URL = 'http://localhost:5000'
export const CLIENT_URL = 'http://localhost:3000/todolist'

export const JWT_ACCESS_SECRET = 'todolist_secret_token'
export const JWT_REFRESH_SECRET = 'todolist_refresh_secret_token'
